# T-Curses

A Tkinter interface that feels like programming in curses
